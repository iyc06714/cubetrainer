# cubetrainer
basically, a better version of Tao Yu's Train Yu but for COLL
